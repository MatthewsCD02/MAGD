function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(212);
  fill('rgb(0,0,0)');
  stroke("black");
  ellipse(350, 50, 80,80);
  noStroke();
  fill('rgb(212,212,212)');
  ellipse(360,40,60,60);
  stroke('rgb(0,0,0)');
  fill('rgb(31,31,31)');
  rect(80,240,50,160);
  fill('rgb(66,66,66)');
  rect(100, 300, 50, 100);
  fill('rgb(15,15,15)');
  rect(15,200,50,200);
  fill('rgb(9,9,9)');
  rect(235, 100, 50, 300);
  fill('rgb(49,49,49)');
  rect(190, 275, 50, 125);
  fill('rgb(20,20,20)');
  rect(290, 215, 50, 185);
  fill('rgb(26,26,26)');
  rect(360, 230, 40, 170);
  stroke('rgb(0,0,0)');
  strokeCap(ROUND);
  strokeWeight(3);
  line(36,45,38,50);
  line(38,50,42,45);
  line(43,51,45,56);
  line(45,56,49,51);
  line(51,65,53,70);
  line(53,70,57,65);
  fill('white');
  stroke('white)');
  point(90,250);
  point(120,250);
  point(110,310);
  point(140,310);
  point(25,210);
  point(55,210);
  point(245,110);
  point(275,110);
  point(200,285);
  point(230,285);
  point(300,225);
  point(330,225);
  point(370,240);
  point(400,240);
}
