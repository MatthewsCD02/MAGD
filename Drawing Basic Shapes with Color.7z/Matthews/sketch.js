function setup() {
  createCanvas(400, 600);
}

function draw() {
  background(0);
  colorMode(RGB, 255, 255, 255, 1);
  noStroke();
  fill(255, 0, 0, 0.5);
  rect(0,0,400,600);
  stroke(255,255,255,1);
  fill(0, 0, 0, 1);
  quad(200,100,300,150,200,200,100,150);
  quad(200,500,300,450,200,400,100,450);
  fill(200,200,0,1);
  quad(200,250,300,300,200,350,100,300);
  fill(0,0,0,1);
  beginShape(TESS);
  vertex(100,400);
  vertex(150,200);
  vertex(200,300);
  vertex(250,200);
  vertex(300,400);
  vertex(280,400);
  vertex(249,220);
  vertex(200,320);
  vertex(151,220);
  vertex(120,400);
  vertex(100,400);
  endShape(CLOSE);
  fill(200,200,0,1);
  triangle(0,0,50,50,0,100);
  triangle(0,500,50,550,0,600);
  triangle(400,0,350,50,400,100);
  triangle(400,500,350,550,400,600);
  noFill();
  curve(100,50,100,50,200,0,0,0);
  curve(300,50,300,50,200,0,400,0);
  curve(100,550,100,550,200,600,0,600);
  curve(300,550,300,550,200,600,400,600);
}